// Norwegian
fb.data.strings = [
"no",
"Avslutt (tast: Esc)",
"Forrige (tast: \u2190)",
"Neste (tast: \u2192)",
"Spill av (tast: mellomrom)",
"Pause (tast: mellomrom)",
"Endre st\u00f8relse (tast: Page Up/Down)",
"Bilde %1 av %2",
"Side %1 av %2",
"(%1 av %2)",
"Info...",
"Trykk...",
"\u00c5pne i nytt vindu",
"Pop-up innhold er blokkert av denne nettleseren."
];

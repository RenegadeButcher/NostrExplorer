// Hungarian
fb.data.strings = [
"hu",
"Bez\u00e1r (Esc)",
"El\u0151z\u0151 (\u2190)",
"K\u00f6vetkez\u0151 (\u2192)",
"Lej\u00e1tsz\u00e1s (space)",
"Meg\u00e1ll\u00edt (space)",
"\u00c1tm\u00e9retez (Tab)",
"%2 k\u00e9pb\u0151l a(z) %1.",
"%2 oldalb\u00f3l a(z) %1.",
"(%1 / %2)",
"Info...",
"Nyomtat...",
"Megnyit\u00e1s \u00faj ablakban",
"Pop-up tartalom le van tiltva a b\u00f6ng\u00e9sz\u0151ben."
];

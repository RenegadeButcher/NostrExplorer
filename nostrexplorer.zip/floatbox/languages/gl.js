// Galician
fb.data.strings = [
"gl",
"Pechar (teclado: Esc)",
"Anterior (teclado: \u2190)",
"Seguinte (teclado: \u2192)",
"Continuar (teclado: barra espaciadora)",
"Parar (teclado: barra espaciadora)",
"Tama\u00f1o (teclado: Page Up/Down)",
"Debuxo %1 de %2",
"P\u00e1xina %1 de %2",
"(%1 de %2)",
"Info...",
"Imprimir...",
"Abrir nunha nova vent\u00e1",
"Pop-up de contido bloqueado por este navegador."
];

// Vietnamese
fb.data.strings = [
"vi",
"\u0110i ra (b\u00e0n ch\u1eef: Esc)",
"K\u1ebf tr\u01b0\u1edbc (b\u00e0n ch\u1eef: \u2190)",
"K\u1ebf sau (b\u00e0n ch\u1eef: \u2192)",
"B\u0103\u0301t \u0111\u00e2\u0300u (b\u00e0n ch\u1eef: r\u1eadp c\u00e1ch ch\u1eef)",
"Ta\u0323m ng\u01b0\u0300ng (b\u00e0n ch\u1eef: r\u1eadp c\u00e1ch ch\u1eef)",
"\u0110\u1ed5i ki\u0301ch th\u01b0\u01a1\u0301c (b\u00e0n ch\u1eef: Page Up/Down)",
"Hi\u0300nh %1 trong %2",
"Trang %1 trong %2",
"(%1 trong %2)",
"Chi ti\u1ebft...",
"In...",
"M\u1edf m\u1ed9t c\u1eeda s\u1ed5 m\u1edbi",
"Popup n\u1ed9i dung b\u1ecb ch\u1eb7n b\u1edfi tr\u00ecnh duy\u1ec7t n\u00e0y."
];

// Finnish
fb.data.strings = [
"fi",
"Poistu (paina: Esc)",
"Edellinen (paina: \u2190)",
"Seuraava (paina: \u2192)",
"Toista (paina: v\u00e4lily\u00f6nti\u00e4)",
"Tauko (paina: v\u00e4lily\u00f6nti\u00e4)",
"Suurenna/pienenn\u00e4 (paina: Page Up/Down)",
"Kuva %1 / %2",
"Sivu %1 / %2",
"(%1 / %2)",
"Info...",
"Tulosta...",
"Avaa uuteen ikkunaan",
"Pop-up sis\u00e4lt\u00f6 on estetty t\u00e4m\u00e4n selaimessa."
];

// Romanian
fb.data.strings = [
"ro",
"Iesire (tasta: Esc)",
"Inapoi (tasta: \u2190)",
"Inainte (tasta: \u2192)",
"Start (tasta: spatiu)",
"Pauza (tasta: spatiu)",
"Redimensionare (tasta: Page Up/Down)",
"Imaginea %1 din %2",
"Pagina %1 din %2",
"(%1 din %2)",
"Detalii...",
"Printare...",
"Deschide \u00eentr-o fereastr\u0103 nou\u0103",
"Pop-up de con\u021binut este blocat \u00een acest browser."
];

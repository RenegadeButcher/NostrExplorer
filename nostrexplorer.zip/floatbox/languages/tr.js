// Turkish
fb.data.strings = [
"tr",
"\u00c7\u0131k\u0131\u015f (tu\u015f: Esc)",
"Geri (tu\u015f: \u2190)",
"\u0130leri (tu\u015f: \u2192)",
"Oynat (tu\u015f: spacebar)",
"Dondur (tu\u015f: spacebar)",
"Boyutland\u0131r (tu\u015f: Page Up/Down)",
"Resim %1 - %2",
"Sayfa %1 - %2",
"(%1 - %2)",
"Bilgi...",
"Yazd\u0131r...",
"A\u00e7\u0131k yeni bir pencerede",
"Pop-up i\u00e7eri\u011fi bu taray\u0131c\u0131da engellenir."
];

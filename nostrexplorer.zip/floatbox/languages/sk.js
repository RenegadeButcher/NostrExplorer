// Slovak
fb.data.strings = [
"sk",
"Zatvori\u0165 (kl\u00e1vesa: Esc)",
"Predch\u00e1dzaj\u00faca (kl\u00e1vesa: \u2190)",
"Nasleduj\u00faca (kl\u00e1vesa: \u2192)",
"Spusti\u0165 prehr\u00e1vanie (kl\u00e1vesa: medzern\u00edk)",
"Pauza (kl\u00e1vesa: medzern\u00edk)",
"Zmeni\u0165 ve\u013ekos\u0165 (kl\u00e1vesa: Page Up/Down)",
"Obr\u00e1zok %1 z %2",
"Strana %1 z %2",
"(%1 z %2)",
"Info...",
"Tla\u010di\u0165...",
"Otvori\u0165 v novom okne",
"Pop-up Obsah je blokovan\u00fd v tomto prehliada\u010di."
];

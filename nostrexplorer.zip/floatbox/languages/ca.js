// Catalan
fb.data.strings = [
"ca",
"Sortida (teclat: Esc)",
"Enrere (teclat: \u2190)",
"Endavant (teclat: \u2192)",
"Activar (teclat: barra espaiadora)",
"Pausa (teclat: barra espaiadora)",
"Mida (teclat: Page Up/Down)",
"Imatge %1 de %2",
"P\u00e0gina %1 de %2",
"(%1 de %2)",
"Info...",
"Imprimir..",
"Obrir en una nova finestra",
"Pop-up contingut s'ha estat blocat per aquest navegador."
];

// Danish
fb.data.strings = [
"da",
"Luk (tast: Esc)",
"Forrige (tast: \u2190)",
"N\u00e6ste (tast: \u2192)",
"Afspil (tast: mellemrum)",
"Pause (tast: mellemrum)",
"Tilpas (tast: Page Up/Down)",
"Billede %1 af %2",
"Side %1 af %2",
"(%1 af %2)",
"Info...",
"Trykke...",
"\u00c5bn i et nyt vindue",
"Pop-up indholdet er blevet blokeret af denne browser."
];

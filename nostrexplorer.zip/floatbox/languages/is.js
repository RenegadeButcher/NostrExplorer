// Icelandic
fb.data.strings = [
"is",
"Loka (takki: Esc)",
"Fyrri (takki: \u2190)",
"N\u00e6sta (takki: \u2192)",
"Spila (takki: spacebar)",
"P\u00e1sa (takki: spacebar)",
"Breita st\u00e6r\u00f0 (takki: Page Up/Down)",
"Mynd %1 af %2",
"S\u00ed\u00f0a %1 af %2",
"(%1 af %2)",
"Uppl\u00fdsingar...",
"Prenta...",
"Opna \u00ed n\u00fdum glugga",
"Pop-upp innihald er l\u00e6st me\u00f0 \u00feessum vafra."
];

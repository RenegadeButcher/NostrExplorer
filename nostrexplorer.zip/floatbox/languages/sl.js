// Slovenian
fb.data.strings = [
"sl",
"Zapri (tipka: Esc)",
"Prej\u0161nja (tipka: \u2190)",
"Naslednja (tipka: \u2192)",
"Predvajaj (tipka: spacebar)",
"Premor (tipka: spacebar)",
"Spremeni velikost (tipka: Page Up/Down)",
"Slika %1 od %2",
"Stran %1 od %2",
"(%1 od %2)",
"Info...",
"Natisni...",
"Odpri v novem oknu",
"Pop-up vsebina je blokirana ki jih ta brskalnik."
];
